
const NuvoSdkAction = {
    login: 'login',
    do: 'transfer',
};

interface TransParams {
    from:string,
    to:string,
    contractAddress:string,
    value:string,
    data:string,
    chainId:number
}

interface LoginParams {
    appId: string;
    appKey:string;
}

interface SdkProps {
    chainId: string;
    appId: string;
    apiHost: string;
    oauthHost: string;
    debug?: boolean;
}

interface LayerProps {
    action: string;
    onCompleted: (data: any) => {};
    data?: LoginParams | SdkProps | any;
}


export { NuvoSdkAction }
export type { TransParams, LoginParams, SdkProps, LayerProps };

